import re
import socket
import threading

HOST = "0.0.0.0"
PORT = 8080

# Formato solicitado: tres letras y tres dígitos del 0 al 9.
# Se aceptan placas con o sin guion/espacios: ABC123, ABC-123, ABC 123.
PATRON_PLACA = re.compile(r"^[A-Z]{3}\d{3}$")
vehiculos_dentro = set()
candado = threading.Lock()


def normalizar_placa(placa: str) -> str:
    return re.sub(r"[\s-]", "", placa.strip().upper())


def procesar_mensaje(mensaje: str) -> str:
    partes = mensaje.strip().split("|", 1)
    if len(partes) != 2:
        return "ERROR|Formato esperado: ENTRADA|ABC123, SALIDA|ABC123, LISTA o ESTADO"

    accion, placa_original = partes
    accion = accion.strip().upper()
    placa = normalizar_placa(placa_original)

    if accion == "ESTADO":
        with candado:
            return f"OK|Dentro: {len(vehiculos_dentro)}"

    if accion == "LISTA":
        with candado:
            lista = ", ".join(sorted(vehiculos_dentro)) if vehiculos_dentro else "(vacío)"
            return f"OK|Vehículos dentro ({len(vehiculos_dentro)}): {lista}"

    if accion not in ("ENTRADA", "SALIDA"):
        return "ERROR|Acción inválida. Usa ENTRADA, SALIDA, LISTA o ESTADO"

    if not PATRON_PLACA.fullmatch(placa):
        return "ERROR|Placa inválida. Usa 3 letras y 3 dígitos del 1 al 9 (ej. ABC123)"

    with candado:
        if accion == "ENTRADA":
            if placa in vehiculos_dentro:
                return f"ERROR|{placa} ya está dentro. Total: {len(vehiculos_dentro)}"
            vehiculos_dentro.add(placa)
            total = len(vehiculos_dentro)
            print(f"[ENTRADA] {placa} | Vehículos dentro: {total}")
            return f"OK|Entrada registrada: {placa}|Dentro: {total}"

        if placa not in vehiculos_dentro:
            return f"ERROR|{placa} no figura dentro del parqueadero. Total: {len(vehiculos_dentro)}"
        vehiculos_dentro.remove(placa)
        total = len(vehiculos_dentro)
        print(f"[SALIDA] {placa} | Vehículos dentro: {total}")
        return f"OK|Salida registrada: {placa}|Dentro: {total}"


def atender_cliente(conn: socket.socket, addr):
    print(f"[+] Cliente conectado: {addr[0]}:{addr[1]}")
    try:
        conn.settimeout(10)
        datos = b""
        while b"\n" not in datos and len(datos) < 4096:
            fragmento = conn.recv(1024)
            if not fragmento:
                break
            datos += fragmento
        if not datos:
            return
        mensaje = datos.decode("utf-8", errors="replace").split("\n", 1)[0]
        respuesta = procesar_mensaje(mensaje)
        conn.sendall((respuesta + "\n").encode("utf-8"))
    except (ConnectionError, OSError, socket.timeout) as error:
        print(f"[!] Error con {addr}: {error}")
    finally:
        conn.close()


def main():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as servidor:
        servidor.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        servidor.bind((HOST, PORT))
        servidor.listen()
        print(f"Servidor de parqueadero activo en {HOST}:{PORT}")
        print("Presiona Ctrl+C para detenerlo.")
        try:
            while True:
                conn, addr = servidor.accept()
                hilo = threading.Thread(
                    target=atender_cliente, args=(conn, addr), daemon=True
                )
                hilo.start()
        except KeyboardInterrupt:
            print("\nServidor detenido.")


if __name__ == "__main__":
    main()

# Sistema de parqueadero distribuido (C++ + Python)

Cliente TCP en C++ y servidor TCP en Python. Se pueden ejecutar en computadores distintos conectados a la misma red Wi-Fi.

## Funcionamiento

- `ENTRADA`: registra una placa si no está dentro.
- `SALIDA`: retira una placa si está dentro.
- `ESTADO`: consulta el número actual de vehículos.
- `LISTA`: muestra las placas actualmente dentro.
- El servidor atiende varias conexiones con hilos y protege el registro compartido con un candado.
- Las placas se normalizan a mayúsculas y se aceptan con o sin guion/espacios.

**Formato configurado:** tres letras y tres dígitos del 0 al 9, por ejemplo `ABC123` o `ABC-123`. Para permitir el dígito `0`, cambia `[1-9]{3}` por `\\d{3}` en `servidor.py`.

## 1. Ejecutar el servidor (computador A)

1. Instala Python 3.
2. Abre una terminal en la carpeta del proyecto.
3. Ejecuta:

   ```bash
   python servidor.py
   ```

El servidor escucha en todas las interfaces de red (`0.0.0.0`) por el puerto TCP `8080`.

### Consultar la IP del servidor

En Windows, ejecuta `ipconfig` y busca la dirección IPv4 del adaptador Wi-Fi, por ejemplo `192.168.1.25`. Usa la IP real del equipo, no el ejemplo.

Si Windows Firewall pregunta, permite Python en redes privadas. Si no aparece el aviso, crea una regla de entrada para TCP puerto `8080`. No expongas ese puerto a Internet.

## 2. Compilar el cliente (computador B, Windows)

Necesitas un compilador C++ con soporte para Winsock, como MinGW-w64 o MSVC.

Con MinGW-w64, desde la carpeta del proyecto:

```bash
g++ Cliente.cpp -o Cliente.exe -lws2_32
```

Con Visual Studio Developer Command Prompt:

```bat
cl /EHsc Cliente.cpp Ws2_32.lib
```

## 3. Ejecutar el cliente

```bat
Cliente.exe 192.168.1.25
```

Reemplaza `192.168.1.25` por la IP local del computador A. Si no pasas una IP como argumento, el programa te la preguntará.

Ambos equipos deben estar en la misma red y la red debe permitir la comunicación entre dispositivos. Algunas redes Wi-Fi de invitados activan aislamiento de clientes, lo que bloquea este tipo de conexión.

## 4. Probar el sistema

1. En el cliente elige `1` y escribe `ABC-123`.
2. Vuelve a elegir `3`: debe indicar `Dentro: 1`.
3. Intenta registrar de nuevo la entrada de `ABC123`: el servidor debe rechazar el duplicado.
4. Elige `2` y escribe `ABC123`.
5. Consulta el estado: debe indicar `Dentro: 0`.
6. Prueba `4` para listar las placas que siguen dentro.

## Limitaciones de esta primera versión

- Los datos se guardan en memoria; si se detiene el servidor, el registro se pierde. Para un proyecto real conviene agregar SQLite.
- La detección de entrada/salida es manual mediante el menú del cliente. No hay cámara ni reconocimiento automático de placas.
- No se ha establecido una capacidad máxima del parqueadero.
- Esta versión valida el formato solicitado, no verifica que una placa exista oficialmente.
